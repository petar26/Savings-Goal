package com.example.savingsgoal;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.HapticFeedbackConstants;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final int FILE_REQUEST = 1001;

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;

    private boolean isNight() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Colors the status bar, navigation bar and WebView background to match the page. */
    private void applyBars(String bgHex, boolean darkBg) {
        int bg;
        try {
            bg = Color.parseColor(bgHex);
        } catch (Exception e) {
            return;
        }
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        View decor = getWindow().getDecorView();
        int flags = decor.getSystemUiVisibility();
        if (darkBg) {
            flags &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        } else {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        decor.setSystemUiVisibility(flags);
        web.setBackgroundColor(bg);
    }

    /** The page calls this whenever its theme or accent changes. */
    private class Bridge {
        @JavascriptInterface
        public void haptic(final String kind) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    playHaptic(kind);
                }
            });
        }

        /** Stronger buzz for a higher level (0 to 100), used by the growing About text. */
        @JavascriptInterface
        public void hapticLevel(final int pct) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    int p = Math.max(0, Math.min(100, pct));
                    buzz(14 + p / 6, 40 + p * 2);
                }
            });
        }

        @JavascriptInterface
        public void setBars(final String bgHex, final boolean dark) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyBars(bgHex, dark);
                }
            });
        }
    }

    private void buzz(long ms, int amplitude) {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null && v.hasVibrator()) {
            v.vibrate(VibrationEffect.createOneShot(ms, amplitude));
        }
    }

    /** Plays a haptic effect. Called from the page, so it hops to the UI thread first. */
    private void playHaptic(String kind) {
        View v = web;
        if ("tick".equals(kind)) {
            v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        } else if ("tap".equals(kind)) {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        } else if ("confirm".equals(kind)) {
            v.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                    ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
        } else if ("reject".equals(kind)) {
            v.performHapticFeedback(Build.VERSION.SDK_INT >= 30
                    ? HapticFeedbackConstants.REJECT : HapticFeedbackConstants.LONG_PRESS);
        } else if ("success".equals(kind)) {
            // goal reached: three quick pulses that build up
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                long[] t = {0, 30, 60, 30, 60, 70};
                int[] a = {0, 110, 0, 170, 0, 255};
                vib.vibrate(VibrationEffect.createWaveform(t, a, -1));
            }
        }
    }

    /** Tells the page whether the phone is in dark mode (used by the "Automatic" theme). */
    private void pushSystemDark() {
        web.evaluateJavascript(
                "window.__setSystemDark && window.__setSystemDark(" + isNight() + ")", null);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // saves the savings, settings, title and picture between launches
        if (Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(false);
        } else {
            s.setForceDark(WebSettings.FORCE_DARK_OFF);
        }

        web.addJavascriptInterface(new Bridge(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pushSystemDark();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                    return true;
                }
                return false;
            }
        });

        // Lets the page's "Choose image" button open the phone's picture picker.
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    Intent pick;
                    if (Build.VERSION.SDK_INT >= 33) {
                        // Android's built-in photo picker (no permissions needed)
                        pick = new Intent(MediaStore.ACTION_PICK_IMAGES);
                    } else {
                        pick = params.createIntent();
                    }
                    startActivityForResult(pick, FILE_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Bar colors until the page loads and sets its own.
        boolean night = isNight();
        applyBars(night ? "#0F150F" : "#F5FBF2", night);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Back closes the menu, dialogs or settings first; it leaves the app only when nothing is open. */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
                "(window.__handleBack ? window.__handleBack() : false) === true",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"true".equals(value)) {
                            finish();
                        }
                    }
                });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        pushSystemDark();
    }
}
