# Savings Goal (Android)

A small Android app that shows the savings tracker page in a WebView. The page lives in `app/src/main/assets/index.html`.

## Build the APK

**Android Studio (easiest)**
1. Open this folder in Android Studio and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

**Command line** (needs the Android SDK and Gradle 8.9 or newer)
```
gradle assembleDebug
```

Copy the APK to your phone and open it. Android will ask you to allow installing from that source.

## Notes
- Debug builds are signed with a debug key, which is fine for your own phone. A Play Store release needs your own signing key.
- The app has no custom launcher icon yet, so Android shows its default one.
- Savings are stored on the phone inside the app. Clearing the app's data resets them.
- The Roboto Flex font loads from Google Fonts when you are online. Offline, the app falls back to the system font.
